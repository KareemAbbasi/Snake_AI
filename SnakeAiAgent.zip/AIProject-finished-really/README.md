# Final Project for Artificial Intelligence course
## Snake Game

### How to use
* `pip3 install -r requirements.txt`  
* `python3 game.py`